import './App.css';
import Test1 from './compoments/test1/Test1';

function App() {
  // let usernsme1="Lokesh"
  // let usernsme2="chaitu"
//passing an object
let person1={name:"Lokesh",age:21,class:"CSE",image:"https://img.freepik.com/free-photo/young-bearded-man-with-striped-shirt_273609-5677.jpg?size=626&ext=jpg&ga=GA1.1.672697106.1717459200&semt=sph"}
let person2={name:"Chaitu",age:31,class:"IT",image:"https://t4.ftcdn.net/jpg/03/83/25/83/240_F_383258331_D8imaEMl8Q3lf7EKU2Pi78Cn0R7KkW9o.jpg"}

    return (
        <div>
            <h1>Hello world!!</h1>
            {/* <Test1 c={usernsme1}></Test1>
            <Test1 c={usernsme2}></Test1> */}
            <Test1 person={person1}></Test1>
            <Test1 person={person2}></Test1>

        </div>
    )
        
}

export default App;
