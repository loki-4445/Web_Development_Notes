import './Test1.css';
import Test2 from '../test2/Test2';
function Test1(props) {

    console.log({props})
    return (
      <div className="person-card">
        {/* <h1>hello world form test1</h1>
            
            <Test2/> */}
            {/* <h2>Username:{props.c}</h2> */}
            <img src={props.person.image} alt="" />
            <h3>Name:{props.person.name}</h3>
            <h3>Name:{props.person.age}</h3>
            <h3>Name:{props.person.class}</h3>

      </div>
    );
}

export default Test1;
