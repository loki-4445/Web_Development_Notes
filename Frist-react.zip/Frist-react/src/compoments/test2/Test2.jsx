import './Test2.css';

function Test2() {
    return (
        <div>
            <h1>hello world form test2</h1>
        </div>
    );
}

export default Test2;
